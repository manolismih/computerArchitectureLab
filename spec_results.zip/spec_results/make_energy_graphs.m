function void = make_graphs()
	spec = {"specbzip2" "spechmmer" "speclbm" "specmcf" "specjeng"};
	yAxisLabel = {"Energy (mJ)" "Peak Power (W)"};

	data = importdata("importEnergyData.txt");
	for graph=1:2
		data = data(:,graph);
		for i=1:5
			energy = data(1 +25*(i-1) : 25*i ,1);
			energy = [ [energy(1:3); 0] energy(4:7) [energy(8:10); 0] energy(11:14) [energy(15:17); 0] energy(18:21) energy(22:25) ];
			energy = transpose(energy);
			bar(energy);
			ylabel(yAxisLabel{graph});
			title(spec{i});
			set(gca, "XTickLabel", {"Cache line:\n16 32 64", "L1d assoc:\n1 2 4 8", "L1d size:\n32 64 128 KB", "L1i assoc:\n1 2 4 8", "L1i size:\n32 64 128 KB", "L2 assoc:\n1 2 4 8", "L2 size: 512KB\n1 2 4 MB"});
			print(spec{i},"-dsvg");
		end
	end
	close all;
end
