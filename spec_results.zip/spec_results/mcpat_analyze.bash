#!/bin/bash
echo -e Energy '\t' Peak Power >> allResultsEnergy.txt
folders=$(find -mindepth 1 -maxdepth 1 -type d | sort)
for i in $folders
do 
	./GEM5ToMcPAT.py "$i/stats.txt" "$i/config.json" inorder_arm.xml -o "$i/mcpat.xml"
	~/cmcpat/mcpat/mcpat -infile "$i/mcpat.xml" -print_level 5 > "$i/mcpat.out"
	./print_energy.py "$i/mcpat.out" "$i/stats.txt" > "$i/energy.txt"
	echo -e "$i" $(grep energy $i/energy.txt | sed s/[^0-9\.]//g) '\t' $(grep 'Peak Power' $i/mcpat.out | sed s/[^0-9\.]//g) >> allResultsEnergy.txt
done

